"""
This module implements the fast generalized subset scan based detector.
"""
from art.detection.subsetscanning.detector import SubsetScanningDetector
