:mod:`art.utils_test`
=====================
.. automodule:: art.utils_test

Trained Models for Unittests, MNIST
-----------------------------------
.. autofunction:: get_classifier_tf
.. autofunction:: get_classifier_kr
.. autofunction:: get_classifier_pt

Trained Models for Unittests, Iris
----------------------------------
.. autofunction:: get_iris_classifier_tf
.. autofunction:: get_iris_classifier_kr
.. autofunction:: get_iris_classifier_pt
