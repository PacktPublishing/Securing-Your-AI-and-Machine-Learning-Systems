Evaluation metrics for model baselines and attacks.

Model baselines metrics per dataset.

Attacks metrics per model. 
