.. _api:

:github_url: https://github.com/Lab41/cyphercat

*************
CypherCat API
*************

Main Function here
-------------------

.. autofunction:: cyphercat.models


Callbacks
---------

.. autoclass:: cyphercat.callbacks.Logger
    :no-undoc-members:
