# libri-train-clean-100
This directory houses the default splits for libri-speech 100 clean