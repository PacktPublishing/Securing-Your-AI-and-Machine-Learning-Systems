# CypherCat default dataset splits in csv format

Default ratios of data splits:

- train: 80% for training
  - four equal splits with following encoding:
      [0]: train_in
      [1]: train_out
      [2]: shadow_in
      [3]: shadow_out
- val:   20% for validation
      [4]: val
