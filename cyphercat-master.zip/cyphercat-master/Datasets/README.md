# Cyphercat Datasets

# Image Datasets
- CiFAR 10
- CiFAR 100
- Tiny ImageNet
- LFW
- AT&T Faces

# Audio Datasets
- LibriSpeech

# Text
- Stanford Sentiment Treebank

