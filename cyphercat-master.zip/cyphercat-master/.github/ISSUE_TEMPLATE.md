Thank you for reporting an issue!

If you're submitting a bug report, please include a self-contained copy-pastable example that reproduces the issue if possible.
