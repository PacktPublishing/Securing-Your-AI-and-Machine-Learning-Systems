
- [ ] Tests added / passed
- [ ] Associated doc strings if new function
- [ ] Passes `flake8`
